# -*- coding: utf-8 -*-
from website import create_app, send_email


application = create_app()

try:
	if __name__ == '__main__':
		application.run(debug=True)
except Exception as error:
	send_email.send('Ошибка на сервере: \n\n' + error)