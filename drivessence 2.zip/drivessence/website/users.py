# -*- coding: utf-8 -*-
from datetime import datetime, date
from flask import request, redirect, url_for
from flask_login import login_user, logout_user

from website.models import User
from website import db


def new_user():
	signUp_date = datetime.strptime(str(date.today()), '%Y-%m-%d').strftime('%d/%m/%Y')

	new_user = User(first_name = request.form.get('first_name'), 
					second_name = request.form.get('second_name'), 
					email=request.form.get('email'), 
					password = generate_password_hash(request.form.get('password'), method = 'sha256'), 
					gender = request.form.get('gender'), 
					signUp_date = signUp_date,
					ipaddr = None)
	db.session.add(new_user)
	db.session.commit()

def edit_user():
	user_id = request.form.get('users')

	user = User.query.filter_by(id=user_id).first()
	user.first_name = request.form.get('first_name')
	user.second_name = request.form.get('second_name')
	user.email = request.form.get('email')
	user.gender = request.form.get('gender')
	db.session.commit()

def enter_user(current_user):
	user_id = request.form.get('users')
	if current_user.email == 'viktar@drivessence.com':
		user = User.query.filter_by(id=user_id).first()
		logout_user()
		login_user(user, remember=True)
		return redirect(url_for('dash.dashboard'))

def delete_user():
	user_id = request.form.get('users')

	user = User.query.filter_by(id=user_id).delete()
	db.session.commit()