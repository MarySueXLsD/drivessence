# -*- coding: utf-8 -*-
import jinja2

from flask import Flask, request
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
from flask_sitemap import Sitemap
from os import path
from werkzeug.utils import secure_filename

from website.global_jinja_functions import calculatePayDay, calculatePayDayMoney, get_percent


db = SQLAlchemy()
DB_NAME = "database.db"

UPLOAD_IMAGES_FOLDER = '/uploads/images/'
UPLOAD_DOCUMENTS_FOLDER = '/uploads/documents/'
ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'gif', 'pdf', 'word', 'rtf'}

def create_app():
	app = Flask(__name__)
	app.config['SECRET_KEY'] = 'lolkekcheburek'
	app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{DB_NAME}'
	app.config['UPLOAD_DOCUMENTS_FOLDER'] = UPLOAD_DOCUMENTS_FOLDER
	db.init_app(app)

	ext = Sitemap(app=app)

	app.jinja_env.globals.update(calculatePayDay=calculatePayDay)
	app.jinja_env.globals.update(calculatePayDayMoney=calculatePayDayMoney)
	app.jinja_env.globals.update(get_percent=get_percent)

	from .views import views
	from .auth import auth
	from .dashboard import dash

	app.register_blueprint(views, url_prefix='/')
	app.register_blueprint(auth, url_prefix='/')
	app.register_blueprint(dash, url_prefix='/')

	from .models import User, Cars, Drivers

	create_database(app)

	login_manager = LoginManager()
	login_manager.login_view = 'auth.login'
	login_manager.init_app(app)

	@login_manager.user_loader
	def load_user(id):
		return User.query.get(int(id))


	return app

def create_database(app):
	if not path.exists('website/'+ DB_NAME):
		db.create_all(app=app)