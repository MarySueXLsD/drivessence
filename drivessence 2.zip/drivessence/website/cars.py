# -*- coding: utf-8 -*-
from datetime import datetime, date, timedelta
from flask import request

from website.models import Cars, Drivers
from website import db


def new_car():
	NC_mileage = request.form.get('mileage')
	mileage = f"{int(NC_mileage):,}".replace(',', '.')
	NC_price = request.form.get('price')
	buy_price = f"{int(NC_price):,}".replace(',', '.')

	NC_buy_time = request.form.get('buy_date')
	buy_time = datetime.strptime(NC_buy_time, '%Y-%m-%d').strftime('%d/%m/%Y')
	NC_insurance_end = request.form.get('insurance_to')
	insurance_end = datetime.strptime(NC_insurance_end, '%Y-%m-%d').strftime('%d/%m/%Y')
	NC_inspection_end = request.form.get('TO')
	inspection_end = datetime.strptime(NC_inspection_end, '%Y-%m-%d').strftime('%d/%m/%Y')
	NC_add_time = date.today()
	add_time = datetime.strptime(str(date.today()), '%Y-%m-%d').strftime('%d/%m/%Y')

	warnings = request.form.get('warnings')

	new_car = Cars(brand = request.form.get('brand').capitalize(), 
				model = request.form.get('model'), 
				tires=request.form.get('tires'), 
				mileage = mileage, 
				plate_nr = request.form.get('number').upper(), 
				service = 0, engine = request.form.get('engine'),
				insurance_end = insurance_end, 
				buy_time = buy_time, 
				year = request.form.get('year'), 
				buy_price = buy_price, 
				user_id=current_user.id, 
				fuel = request.form.get('type'), 
				inspection_end = inspection_end, 
				month_income = 0, 
				extra_spend = 0, 
				already_earned = 0, 
				is_sold = False, 
				sold_price = 0, 
				total_profit = 0, 
				driver_list = None, 
				warnings = warnings, 
				add_time = add_time, 
				NC_mileage = NC_mileage, 
				NC_insurance_end = NC_insurance_end, 
				NC_buy_time = NC_buy_time, 
				NC_add_time = NC_add_time, 
				NC_inspection_end = NC_inspection_end, 
				NC_price = NC_price, 
				is_active = False, 
				is_working = 'no', 
				driver = None, 
				driver_id = None)
	db.session.add(new_car)
	db.session.commit()

def edit_car():
	car_id = request.form.get('cars')
	car = Cars.query.filter_by(id=car_id).first()

	car.brand = request.form.get('brand')
	car.model = request.form.get('model')
	car.year = request.form.get('year')

	if car.driver:
		driver = Drivers.query.filter_by(id=car.driver_id).first()
		driver.car = f"{car.brand} {car.model} {car.year}" #({car.engine} {car.fuel}) {car.tires[0]} {car.plate_nr}

				

	car.engine = request.form.get('engine')
	car.plate_nr = request.form.get('number')
	car.tires = request.form.get('tires')
	car.fuel = request.form.get('type')
	car.warnings = request.form.get('warnings')

	insurance_end = request.form.get('insurance_to')
	car.NC_insurance_end = insurance_end
	car.insurance_end = datetime.strptime(insurance_end, '%Y-%m-%d').strftime('%d/%m/%Y')

	inspection_end = request.form.get('TO')
	car.NC_inspection_end = inspection_end
	car.inspection_end = datetime.strptime(inspection_end, '%Y-%m-%d').strftime('%d/%m/%Y')

	buy_time = request.form.get('buy_date')
	car.NC_buy_time = buy_time
	car.buy_time = datetime.strptime(buy_time, '%Y-%m-%d').strftime('%d/%m/%Y')

	price = request.form.get('price')
	car.NC_price = price
	car.buy_price = f"{int(price):,}".replace(',', '.')

	mileage = request.form.get('mileage')
	car.NC_mileage = mileage
	car.mileage = f"{int(mileage):,}".replace(',', '.')

	db.session.commit()

def sell_car():
	pass

def delete_car():
	car_id = request.form.get('cars')

	car = Cars.query.filter_by(id=car_id).delete()
	db.session.commit()