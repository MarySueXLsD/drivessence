# -*- coding: utf-8 -*-
from flask_login import UserMixin
from sqlalchemy.sql import func

from website import db



class Cars(db.Model):
	"""
	NC in the name of the column stands for Not Converted (using for date-type calculations)
	"""
	__tablename__ = 'cars'
	id = db.Column(db.Integer, primary_key=True)
	brand = db.Column(db.String(150))
	model = db.Column(db.String(150))
	year = db.Column(db.Integer, nullable = False)
	engine = db.Column(db.String(150))
	fuel = db.Column(db.String(150))
	mileage = db.Column(db.String(150))
	NC_mileage = db.Column(db.String(150))
	plate_nr = db.Column(db.String(150))
	service = db.Column(db.String(150)) #not used
	tires = db.Column(db.String(150))
	insurance_start = db.Column(db.String(150)) #not used
	insurance_end = db.Column(db.String(150))
	NC_insurance_end = db.Column(db.String(150)) #NC
	inspection_end = db.Column(db.String(150))
	NC_inspection_end = db.Column(db.String(150))#NC
	add_time = db.Column(db.String(150))
	NC_add_time = db.Column(db.String(150)) #NC
	buy_time = db.Column(db.String(150))
	NC_buy_time = db.Column(db.String(150)) #NC
	buy_price = db.Column(db.String(150))
	NC_price = db.Column(db.String(150)) #NC
	is_active = db.Column(db.Boolean, default=False, nullable = False) #NOT FOR USE
	month_income = db.Column(db.Integer, nullable = False)
	extra_spend = db.Column(db.Integer, nullable = False)
	already_earned = db.Column(db.Integer, nullable = False)
	is_sold = db.Column(db.Boolean, default=False, nullable = False)
	sold_price = db.Column(db.Integer, nullable = False)
	total_profit = db.Column(db.Integer, nullable = False)
	driver_list = db.Column(db.String(10000)) #NOT FOR USE
	############################################################## CARS <---> DRIVERS ###############################
	warnings = db.Column(db.String(10000))
	user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
	driver_id = db.Column(db.Integer)
	driver = db.Column(db.String(10000))
	is_working = db.Column(db.String(150))
	startDate = db.Column(db.String(150))
	payday = db.Column(db.String(150)) #USE IT
	NC_startDate = db.Column(db.String(150)) #NC



class Drivers(db.Model):
	__tablename__ = 'drivers'
	id = db.Column(db.Integer, primary_key=True)
	name = db.Column(db.String(150))
	surname = db.Column(db.String(150))
	nationality = db.Column(db.String(150))
	birthDate = db.Column(db.String(150))
	NC_birthDate = db.Column(db.String(150)) #NC
	age = db.Column(db.Integer)
	document_nr = db.Column(db.String(50))
	endDate = db.Column(db.String(150)) #not used
	NC_endDate = db.Column(db.String(150)) #not used #NC
	how_long = db.Column(db.String(150)) #not used
	income = db.Column(db.Integer)
	total_paid = db.Column(db.Integer) #not used
	NC_total_paid = db.Column(db.Integer) #not used #NC
	car_list = db.Column(db.String(10000)) #NOT FOR USE
	pesel = db.Column(db.Integer, nullable = False)
	phone = db.Column(db.String(50))
	adress = db.Column(db.String(150))
	############################################################## CARS <---> DRIVERS ###############################
	warnings = db.Column(db.String(10000))
	user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
	car_id = db.Column(db.Integer)
	car = db.Column(db.String(10000))
	is_working = db.Column(db.Boolean, default=False, nullable = False)
	startDate = db.Column(db.String(150))
	payday = db.Column(db.String(150))
	NC_startDate = db.Column(db.String(150)) #NC


class Files(db.Model):
	__tablename__: 'files'
	id = column = db.Column(db.Integer, primary_key=True)
	filename = db.Column(db.String(150))
	data = db.Column(db.LargeBinary)


class User(db.Model, UserMixin):
	__tablename__ = 'user'
	id = db.Column(db.Integer, primary_key=True)
	email = db.Column(db.String(50), unique=True)
	password = db.Column(db.String(50))
	first_name = db.Column(db.String(50))
	second_name = db.Column(db.String(50))
	gender = db.Column(db.String(50))
	signUp_date = db.Column(db.String(50))
	ipaddr = db.Column(db.String(50))
	is_admin = db.column(db.Boolean)
	cars = db.relationship('Cars')
	drivers = db.relationship('Drivers')