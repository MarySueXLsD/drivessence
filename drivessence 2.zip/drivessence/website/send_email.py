# -*- coding: utf-8 -*-
import smtplib


def send(whole_log):
	email = dict()
	email['from'] = 'noreply@drivessence.com'
	email['to'] = 'viktar@drivessence.com'
	email['subject'] = 'Ktoś napisał do ciebie przez twoją stronę internetową!'

	#DELETE SPAM
	if 'https://' in whole_log:
		return None
	else:

		email['body'] = f'Subject: {email["subject"]}\n\n{whole_log}'

		password = 'sAint_aLlah^'

		with smtplib.SMTP(host='mail.privateemail.com', port=587) as smtp:
			smtp.ehlo() #start
			smtp.starttls() #encrypt
			smtp.ehlo() #start again

			smtp.login(email['from'], password)
			smtp.sendmail(email['from'], email['to'], email['body'].encode("UTF-8")) #me
			#smtp.sendmail(email['from'], 'alesia@drivessence.com', email['body'].encode("UTF-8")) #alesia

def send_error(error):
	email = dict()
	email['from'] = 'noreply@drivessence.com'
	email['to'] = 'viktar@drivessence.com'
	email['subject'] = 'Caught an error in the Drivessence System!'

	email['body'] = f'Subject: {email["subject"]}\n\n{error}'
	password = 'sAint_aLlah^'

	with smtplib.SMTP(host='mail.privateemail.com', port=587) as smtp:
		smtp.ehlo() #start
		smtp.starttls() #encrypt
		smtp.ehlo() #start again

		smtp.login(email['from'], password)
		smtp.sendmail(email['from'], email['to'], email['body'].encode("UTF-8")) #me