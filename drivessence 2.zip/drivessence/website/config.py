# -*- coding: utf-8 -*-
class Config(object):
	LANGUAGES = ['en', 'pl', 'ru']