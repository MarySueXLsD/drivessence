# -*- coding: utf-8 -*-
from datetime import datetime, date, timedelta
from flask import request

from website.models import Cars, Drivers
from website import db


def calculate_age(NC_birthDate):
	birthday = datetime.strptime(NC_birthDate, '%Y-%m-%d').strftime('%d/%m/%Y')
	birthday_splitted = birthday.split('/')
	day, month, year = birthday_splitted
	today = date.today()
	age = today.year - int(year) - ((today.month, today.day) < (int(month), int(day)))
	return age

def confirm_payment():
	driver_id = request.form.get('driver')
	driver = Drivers.query.filter_by(id=driver_id).first()
	car = Cars.query.filter_by(id=driver.car_id).first()
	payday = datetime.strptime(driver.payday, '%Y-%m-%d').date()
	paydayDate = payday + timedelta(days=7)
	driver.payday = paydayDate
	driver.total_paid += driver.income
	car.already_earned += driver.income
	db.session.commit()

def active_drivers(current_user):
	active_drivers = 0
	for driver in current_user.drivers:
		if driver.is_working:
			active_drivers += 1
	return active_drivers

def active_cars(current_user):
	active_cars = 0
	for car in current_user.cars:
		if car.is_working == 'yes':
			active_cars += 1
	return active_cars

def write_to_file(data):
	with open('submitted_form_log.txt', mode = 'a') as form_log:
		name = data['name'].capitalize()
		surname = data['surname'].capitalize()
		email = data['email']
		phone = data['phone']
		if 'car' in data.keys():
			car = 'Ma własny samochód'
		else:
			car = 'Potrzebuje firmowy samochód'
		message = data['message']
		### GENERAL INFO ABOVE ###

		whole_log = f'Imię i nazwisko:\n{name} {surname}\nEmail: {email}\nTelefon: {phone}\n{car}\nWiadomość:\n\n{message}'
		# Writing to TXT
		file = form_log.write(f'\n\n[***]\n{whole_log.encode("UTF-8")}')
		# Sending to email
		send_email.send(whole_log)

def get_total_income(current_user):
	income = 0
	earned = 0
	for drivers in current_user.drivers:
		if drivers.income == None: 
			drivers.income = 0
			db.session.commit()
			error = f"User ID: {current_user.id}\nEmail: {current_user.email}\n[*****]\nIssue with calculating income (NoneType)\nDriver ID: {drivers.id}\nDriver Name: {drivers.name} {drivers.surname}\n\n Got fixed by replacing None to 0"
			send_email.send_error(error)
		income += drivers.income
	for cars in current_user.cars:
		earned += cars.already_earned
	return income, earned

def is_file_allowed(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS