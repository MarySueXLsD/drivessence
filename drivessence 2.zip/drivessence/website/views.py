# -*- coding: utf-8 -*-
import re
from flask import Blueprint, render_template


views = Blueprint('views', __name__)

@views.route('/')
def home():
	return render_template("index.html")
	
@views.route('/ru')
def home_ru():
    return render_template('index_ru.html')
    
@views.route('/ua')
def home_ua():
    return render_template('index_ua.html')

@views.route('/thankyou', methods=['POST', 'GET'])
def submit_form():
    if request.method == 'POST':
    	data = request.form.to_dict()
    	write_to_file(data)
    	return render_template('thank_you.html')
    else:
    	return render_template('404.html', wrong_page_name = page_name)
    	
@views.route('thankyou_ru', methods=['POST', 'GET'])
def submit_form2():
    if request.method == 'POST':
    	data = request.form.to_dict()
    	write_to_file(data)
    	return render_template('thank_you_ru.html')
    else:
    	return render_template('404.html', wrong_page_name = page_name)
    	
@views.route('thankyou_ua', methods=['POST', 'GET'])
def submit_form3():
    if request.method == 'POST':
    	data = request.form.to_dict()
    	write_to_file(data)
    	return render_template('thank_you_ua.html')
    else:
    	return render_template('404.html', wrong_page_name = page_name)

@views.route('/<page_name>')
def page404(page_name):
	return render_template('404.html', wrong_page_name = page_name)