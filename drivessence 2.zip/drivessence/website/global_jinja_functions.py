# -*- coding: utf-8 -*-
from datetime import date, datetime


def calculatePayDay(paydayDate):
	"""
	Is using for calculating how many days left till the end of the term.
	"""
	currentDate = date.today()
	paydayObj = datetime.strptime(paydayDate, '%Y-%m-%d').date()
	payday = paydayObj - currentDate

	if payday.days == -1:
		payday = 'Wczoraj'
	elif payday.days < -1: 
		payday = 'Już po, trzeba coś zrobić'
	elif str(payday.days)[-1] == '1':                                                 #IF ENDS WITH 1
		if len(str(payday.days)) > 1:												#IF THE LENGTH MORE THAN 1 (10, 21, 213)
			if str(payday.days)[-2] != '11':										#IF NOT ENDS WITH 11
				payday = 'Został ' + str(payday.days) + ' dzień' #21,31,41,51 	
			else:																	
				payday = 'Zostało ' + str(payday.days) + ' dni' #11
		else:
			payday = 'Został ' + str(payday.days) + ' dzień' #1
	elif payday.days > 0:															#THE REST
		payday = 'Zostało ' + str(payday.days) + ' dni' #2,5,15,22,33,812
	elif payday.days == 0:
		payday = 'Dzisiaj' #USE IT IN IF ELSE IN JINJA

	return payday


def calculatePayDayMoney(paydayDate):
	"""
	Similiar to the previous one but is using only for the paydays and shows how many days left till the payment or how long someone is not paying.
	"""
	currentDate = date.today()
	paydayObj = datetime.strptime(paydayDate, '%Y-%m-%d').date()
	payday = paydayObj - currentDate

	if payday.days == -1:
		payday = 'Wczoraj'
	elif payday.days < -1: 
		payday = payday.days
	elif str(payday.days)[-1] == '1':                                                 #IF ENDS WITH 1
		if len(str(payday.days)) > 1:												#IF THE LENGTH MORE THAN 1 (10, 21, 213)
			if str(payday.days)[-2] != '11':										#IF NOT ENDS WITH 11
				payday = 'Został ' + str(payday.days) + ' dzień' #21,31,41,51 	
			else:																	
				payday = 'Zostało ' + str(payday.days) + ' dni' #11
		else:
			payday = 'Został ' + str(payday.days) + ' dzień' #1
	elif payday.days > 0:															#THE REST
		payday = 'Zostało ' + str(payday.days) + ' dni' #2,5,15,22,33,812
	elif payday.days == 0:
		payday = 'Dzisiaj' #USE IT IN IF ELSE IN JINJA

	return payday


def get_percent(first, second):
	return int(first)/int(second)*100