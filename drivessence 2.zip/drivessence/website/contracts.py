# -*- coding: utf-8 -*-
from datetime import datetime, date, timedelta
from flask import request

from website.models import Cars, Drivers
from website import db


def new_contract():
	startDate = request.form.get('startDate')
	startDateObj = datetime.strptime(startDate, '%Y-%m-%d')
	income = int(request.form.get('income'))
	paydayDate = startDateObj + timedelta(days=7)
	paydayDate = paydayDate.date()

	car_id = request.form.get('car')
	car = Cars.query.filter_by(id=car_id).first()

	driver_id = request.form.get('driver')
	driver = Drivers.query.filter_by(id=driver_id).first()

	car.driver_id = driver.id
	car.driver = f"{driver.name} {driver.surname}"
	car.is_working = 'yes'
	car.NC_startDate = startDate
	car.startDate = datetime.strptime(startDate, '%Y-%m-%d').strftime('%d/%m/%Y')

	driver.car_id = car.id
	driver.car = f"{car.brand} {car.model} {car.year}" #({car.engine} {car.fuel}) {car.tires[0]} {car.plate_nr}
	driver.is_working = True
	driver.income = income
	driver.NC_startDate = startDate
	driver.startDate = datetime.strptime(startDate, '%Y-%m-%d').strftime('%d/%m/%Y')
	driver.payday = paydayDate
	db.session.commit()