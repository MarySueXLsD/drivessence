# -*- coding: utf-8 -*-
import random 


def random_polish_quote():
	list_of_quotes = (
	'Mistrzowie grają dotąd, aż grają dobrze!',
	'Czyń tylko to co podpowiada Ci serce!',
	'Kiedyś – nie ma takiego dnia tygodnia!',
	'Marzenie jest formą planowania!',
	'Nie ograniczaj siebie. Jesteś wszystkim, co masz!'
	)

	random_quote = random.choice(list_of_quotes)
	return random_quote