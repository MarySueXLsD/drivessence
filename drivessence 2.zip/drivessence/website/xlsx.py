# -*- coding: utf-8 -*-
import xlsxwriter

from website.general_functions import get_total_income


def generate(current_user):
	workbook = xlsxwriter.Workbook(f'website/userDocuments/user{current_user.id}/drivessence.xlsx')
	worksheet0 = workbook.add_worksheet('General')
	worksheet1 = workbook.add_worksheet('Drivers')
	worksheet2 = workbook.add_worksheet('Cars')

	title = workbook.add_format()
	title.set_bold()
	title.set_align('center')

	#Defining the sizes of columns
	worksheet0.set_column(0, 0, 30)
	worksheet0.set_column(1, 1, 35)
	worksheet0.set_column(2, 2, 25)
	worksheet0.set_column(3, 3, 20)
	worksheet0.set_column(4, 4, 20)
	worksheet0.set_column(5, 5, 25)
	worksheet0.set_column(6, 6, 10)

	income, earned = get_total_income(current_user)

	worksheet0.write('A1', f"{current_user.first_name} {current_user.second_name}", title)
	worksheet0.write('A2', f"W całości zarobiono {earned}zł", title)
	worksheet0.write('A3', f"Miesięczne dochody: {income}zł", title)
	#progres zwrotu i aktywne kierowce

#########################################################

	#Defining the sizes of columns
	worksheet1.set_column(0, 0, 30)
	worksheet1.set_column(1, 1, 35)
	worksheet1.set_column(2, 2, 25)
	worksheet1.set_column(3, 3, 20)
	worksheet1.set_column(4, 4, 20)
	worksheet1.set_column(5, 5, 25)
	worksheet1.set_column(6, 6, 10)
	worksheet1.set_column(6, 6, 50)

	worksheet1.write('A1', 'Kierowca', title)
	worksheet1.write('B1', 'Samochód', title)
	worksheet1.write('C1', 'Narodowość i peseł', title)
	worksheet1.write('D1', 'Adres', title)
	worksheet1.write('E1', 'Nr Telefonu', title)
	worksheet1.write('F1', 'Data Urodzenia', title)
	worksheet1.write('G1', 'Przychody', title)
	worksheet1.write('H1', 'Uwagi', title)

	rowIndex = 3

	for driver in current_user.drivers:
		if driver.is_working:
			worksheet1.write('A' + str(rowIndex), f"{driver.name} {driver.surname} {driver.document_nr}")
			worksheet1.write('B' + str(rowIndex), f"{driver.car} od {driver.startDate}")
			worksheet1.write('C' + str(rowIndex), f"{driver.nationality}, {driver.pesel}")
			worksheet1.write('D' + str(rowIndex), f"{driver.adress}")
			worksheet1.write('E' + str(rowIndex), f"{driver.phone}")
			worksheet1.write('F' + str(rowIndex), f"{driver.birthDate} (Wiek: {driver.age})")
			worksheet1.write('G' + str(rowIndex), f"{driver.income}zł")
			worksheet1.write('H' + str(rowIndex), f"{driver.warnings}")

			rowIndex += 1

#########################################################

	#Defining the sizes of columns
	worksheet2.set_column(0, 0, 45)
	worksheet2.set_column(1, 1, 32)
	worksheet2.set_column(2, 2, 15)
	worksheet2.set_column(3, 3, 15)
	worksheet2.set_column(4, 4, 15)
	worksheet2.set_column(5, 5, 10)
	worksheet2.set_column(6, 6, 10)
	worksheet2.set_column(6, 6, 50)

	worksheet2.write('A1', 'Samochód', title)
	worksheet2.write('B1', 'Kierowca', title)
	worksheet2.write('C1', 'OC/AC', title)
	worksheet2.write('D1', 'TO', title)
	worksheet2.write('E1', 'Przebieg', title)
	worksheet2.write('F1', 'Cena', title)
	worksheet2.write('G1', 'Data Zakupu', title)
	worksheet2.write('H1', 'Uwagi', title)

	rowIndex = 3

	for car in current_user.cars:
		worksheet2.write('A' + str(rowIndex), f"{car.brand} {car.model} {car.year} ({car.engine} {car.fuel}) {car.tires[0]} {car.plate_nr}")
		if not car.driver_id:
			worksheet2.write('B' + str(rowIndex), "Brak")
		else:
			worksheet2.write('B' + str(rowIndex), f"{car.driver} od {car.startDate}")
		worksheet2.write('C' + str(rowIndex), f"{car.insurance_end}")
		worksheet2.write('D' + str(rowIndex), f"{car.inspection_end}")
		worksheet2.write('E' + str(rowIndex), f"{car.mileage}km")
		worksheet2.write('F' + str(rowIndex), f"{car.NC_price}zł")
		worksheet2.write('G' + str(rowIndex), f"{car.buy_time}")
		worksheet2.write('H' + str(rowIndex), f"{car.warnings}")

		rowIndex += 1

	workbook.close()
	

def generate_userList(current_user, users):
	workbook = xlsxwriter.Workbook(f'website/userDocuments/user{current_user.id}/userList.xlsx')
	worksheet = workbook.add_worksheet('User List')

	title = workbook.add_format()
	title.set_bold()
	title.set_align('center')

	#Defining the sizes of columns
	worksheet.set_column(0, 0, 5)
	worksheet.set_column(1, 1, 15)
	worksheet.set_column(2, 2, 15)
	worksheet.set_column(3, 3, 30)
	worksheet.set_column(4, 4, 10)
	worksheet.set_column(5, 5, 10)
	worksheet.set_column(6, 6, 15)

	worksheet.write('A1', 'ID', title)
	worksheet.write('B1', 'Name', title)
	worksheet.write('C1', 'Surname', title)
	worksheet.write('D1', 'Email', title)
	worksheet.write('E1', 'Gender', title)
	worksheet.write('F1', 'Sign-Up Date', title)
	worksheet.write('G1', 'IP Address', title)

	rowIndex = 3

	for user in users:
		worksheet.write('A' + str(rowIndex), user.id)
		worksheet.write('B' + str(rowIndex), user.first_name)
		worksheet.write('C' + str(rowIndex), user.second_name)
		worksheet.write('D' + str(rowIndex), user.email)
		worksheet.write('E' + str(rowIndex), user.gender)
		worksheet.write('F' + str(rowIndex), user.signUp_date)
		worksheet.write('G' + str(rowIndex), user.ipaddr)

		rowIndex += 1

	workbook.close()