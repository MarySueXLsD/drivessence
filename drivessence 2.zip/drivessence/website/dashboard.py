# -*- coding: utf-8 -*-
import re
import os

from flask import Blueprint, render_template, request, redirect, url_for, send_file
from flask_login import login_user, login_required, logout_user, current_user
from werkzeug.security import check_password_hash, generate_password_hash

from website import db

from website import send_email
from website import info_gather
from website import xlsx

from website.cars import new_car, edit_car, sell_car, delete_car
from website.contracts import new_contract
from website.drivers import new_driver, edit_driver, fire_driver, delete_driver
from website.users import new_user, edit_user, enter_user, delete_user
from website.general_functions import active_drivers, active_cars, calculate_age, confirm_payment, get_total_income, write_to_file
from website.models import Cars, Drivers, User
from website.quotes import random_polish_quote


dash = Blueprint('dash', __name__)

@dash.route('/dashboard', methods = ['GET', 'POST'])
@login_required
def dashboard():
	info_gather.check_ip(current_user)

	if request.method == 'POST':
		if 'confirm pay' in request.form:
			confirm_payment()

	income, earned = get_total_income(current_user)

	return render_template('dashboard.html', user=current_user, income=income, quote = random_polish_quote(), already_earned = earned)

@dash.route('/cars', methods = ['GET', 'POST'])
@login_required
def cars():
	if request.method == 'POST':
		if 'new car' in request.form:
			new_car()

		elif 'edit car' in request.form:
			edit_car()

		elif 'sell car' in request.form:
			pass

		elif 'delete car' in request.form:
			delete_car()

		elif 'contract has been made' in request.form:
			new_contract()

	info_gather.check_ip(current_user)
	return render_template('cars.html', user=current_user, active_drivers = active_drivers(current_user))


@dash.route('/drivers', methods = ['GET', 'POST'])
@login_required
def drivers():
	if request.method == 'POST':
		if 'new driver' in request.form:
			new_driver()

		elif 'edit driver' in request.form:
			edit_driver()

		elif 'fire driver' in request.form:  											# to take driver out of the car #DELETE
			fire_driver()

		elif 'delete driver' in request.form:
			delete_driver()

	info_gather.check_ip(current_user)
	return render_template('drivers.html', user=current_user, active_drivers = active_drivers(current_user))


@dash.route('/make_contract', methods = ['GET', 'POST'])
@login_required
def contract():
	return render_template('contract.html', user = current_user, active_drivers = active_drivers(current_user), active_cars = active_cars(current_user))


@dash.route('/user_control', methods = ['GET', 'POST'])
@login_required
def user_control():
	if current_user.email != 'viktar@drivessence.com':
		return render_template('404.html', wrong_page_name = 'user_control')
	elif current_user.email == 'viktar@drivessence.com':
		if request.method == 'POST':
			if 'new account' in request.form:
				new_user()

			elif 'edit account' in request.form:
				edit_user()

			elif 'enter account' in request.form:
				enter_user(current_user)

			elif 'delete account' in request.form:
				delete_user()

		user_list = User.query.all()
		info_gather.check_ip(current_user)

		return render_template('users.html', user=current_user, users = user_list)

@dash.route('/DrivessenceExcel')
@login_required
def downloadExcel():

	if not os.path.isdir(f"website/userDocuments/user{current_user.id}"):
		os.mkdir(f'website/userDocuments/user{current_user.id}')

	xlsx.generate(current_user)
	return send_file(f'userDocuments/user{current_user.id}/drivessence.xlsx')

@dash.route('/UserList')
@login_required
def downloadUserList():

	if not os.path.isdir(f"website/userDocuments/user{current_user.id}"):
		os.mkdir(f'website/userDocuments/user{current_user.id}')

	user_list = User.query.all()

	xlsx.generate_userList(current_user, user_list)
	return send_file(f'userDocuments/user{current_user.id}/userList.xlsx')

@dash.route('/new_car')
@login_required
def new_car():
	return render_template('new_car.html', user=current_user)

@dash.route('/new_driver')
@login_required
def new_driver():
	return render_template('new_driver.html', user=current_user)

@dash.route('/new_user')
@login_required
def new_user():
	if current_user.email != 'viktar@drivessence.com':
		return render_template('404.html', wrong_page_name = 'new_user')
	elif current_user.email == 'viktar@drivessence.com':
		return render_template('new_user.html', user=current_user)