# -*- coding: utf-8 -*-
from datetime import datetime, date, timedelta
from flask import request

from website.general_functions import calculate_age
from website.models import Cars, Drivers
from website import db


def new_driver():
	try:
		#NC_endDate = request.form.get('endDate')
		#endDate = datetime.strptime(NC_endDate, '%Y-%m-%d').strftime('%d/%m/%Y')
		#NC_startDate = date.today()
		#startDate = datetime.strptime(str(date.today()), '%Y-%m-%d').strftime('%d/%m/%Y')
		warnings = request.form.get('warnings')
		birthDate = request.form.get('birthday')
		NC_birthDate = birthDate
		birthday = datetime.strptime(str(birthDate), '%Y-%m-%d').strftime('%d/%m/%Y')
		#file = request.files('file')
				
		age = calculate_age(request.form.get('birthday'))
	except Exception as e:
		return render_template('drivers.html', user=current_user, error = e, active_drivers = active_drivers(current_user))

	new_driver = Drivers(name = request.form.get('name'), 
				surname = request.form.get('surname').capitalize(), 
				nationality=request.form.get('nationality'), 
				document_nr = request.form.get('document_nr').upper(),
				pesel = request.form.get('pesel'), 
				phone = request.form.get('phone'), 
				adress = request.form.get('adress'),
				birthDate = birthday, 
				age = age,  
				startDate = 0,
				endDate = 0, 
				how_long = 0, 
				income = 0,
				total_paid = 0, 
				car_list = 0, 
				car = 0, 
				car_id = 0, 
				NC_startDate = 0,
				NC_endDate = 0, 
				is_working = False, 
				NC_total_paid = 0, 
				NC_birthDate = NC_birthDate, 
				warnings = warnings, 
				user_id=current_user.id)
	db.session.add(new_driver)
	db.session.commit()


def edit_driver():
	driver_id = request.form.get('drivers')
	driver = Drivers.query.filter_by(id=driver_id).first()

	driver.name = request.form.get('name').capitalize()
	driver.surname = request.form.get('surname').capitalize()

	if driver.car != None and driver.car != '0' and driver.car != False:
	    car = Cars.query.filter_by(id=driver.car_id).first()
	    car.driver = f"{driver.name} {driver.surname}"

	driver.document_nr = request.form.get('document_nr').upper()
	driver.nationality = request.form.get('nationality')
	driver.warnings = request.form.get('warnings') 
	driver.pesel = request.form.get('pesel') 
	driver.phone = request.form.get('phone')
	driver.adress = request.form.get('adress')

	startDate = request.form.get('startDate')
	if startDate != None:
		driver.NC_startDate = startDate
		driver.startDate = datetime.strptime(str(startDate), '%Y-%m-%d').strftime('%d/%m/%Y')

	birthDate = request.form.get('birthday')
	driver.NC_birthDate = birthDate
	driver.birthDate = datetime.strptime(str(birthDate), '%Y-%m-%d').strftime('%d/%m/%Y')
	driver.age = calculate_age(birthDate)
	driver.income = request.form.get('income')
	db.session.commit()


def fire_driver():
	driver_id = request.form.get('drivers')
	driver = Drivers.query.filter_by(id=driver_id).first()
	car = Cars.query.filter_by(id=driver.car_id).first()
	car.driver_id = None
	car.driver = None
	car.is_working = 'no'
	car.startDate = None
	car.NC_startDate = 0
	driver.car_id = None
	driver.car = None
	driver.is_working = False
	driver.startDate = 0
	driver.NC_startDate = 0
	driver.income = 0

	db.session.commit()


def delete_driver():
	driver_id = request.form.get('drivers')

	driver = Drivers.query.filter_by(id=driver_id).delete()
	db.session.commit()