# -*- coding: utf-8 -*-
from datetime import datetime, date
from flask import Blueprint, render_template, request, redirect, url_for
from flask_login import login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash

from website.models import User
from website import db


auth = Blueprint('auth', __name__)


@auth.route('/login', methods=['GET', 'POST'])
def login():
	if request.method == 'POST':
		email = request.form.get('email')
		password = request.form.get('password')
		user = User.query.filter_by(email=email).first()
		if user:
			if check_password_hash(user.password, password):
				login_user(user, remember=True)
				return redirect(url_for('dash.dashboard'))
			else:
				return render_template('login.html', error='Wrong email or password')
		else:
			return render_template('login.html', error='Wrong email or password')
	return render_template('login.html')


@auth.route('/registration', methods=['GET', 'POST'])
def registration():
	if request.method == 'POST':
		first_name = request.form.get('first_name')
		second_name = request.form.get('second_name')

		email = request.form.get('email')
		existing_user = User.query.filter_by(email=email).first()
		if existing_user:
			return render_template('registration.html', error = 'User with this email address already registered')

		password1 = request.form.get('password1')
		password2 = request.form.get('password2')
		if password1 != password2:
			return render_template('registration.html', error = 'Passwords do not match up. Try again.')

		signUp_date = datetime.strptime(str(date.today()), '%Y-%m-%d').strftime('%d/%m/%Y')


		user = User(
			email=email, 
			password=generate_password_hash(password1, method = 'sha256'), 
			first_name = first_name, 
			second_name = second_name, 
			gender = 'male', 
			signUp_date = signUp_date,
			ipaddr = request.remote_addr)
		db.session.add(user)
		db.session.commit()

		login_user(user, remember=True)
		return redirect(url_for('dash.dashboard'))

	return render_template('registration.html')


@auth.route('/logout')
@login_required
def logout():
	logout_user()
	return redirect(url_for('auth.login'))