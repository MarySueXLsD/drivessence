# -*- coding: utf-8 -*-
from flask import request

from website import db


def check_ip(current_user):
	if current_user.ipaddr != request.remote_addr:
		current_user.ipaddr = request.remote_addr
		db.session.commit()